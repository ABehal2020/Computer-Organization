#include <stdio.h>
#include <stdlib.h>


void checkpoint2(char* filename)
{
  // open file
  
  // get size of file
  
  // allocate appropriate amount of space for parsing the file as longs
  
  // read in file
  
  // output parsed contents
  
  // close file
}

void checkpoint3(char* filename)
{
  // open file
  
  // get size of file
  
  // allocate appropriate amount of space for parsing the file as unsigned ints
  
  // read in file
  
  // output parsed contents
  
  // close file
}


int main()
{
  char filename[256];
  scanf("%s", filename);
  
  checkpoint2(filename);
  checkpoint3(filename);
  
  return 0;
}
